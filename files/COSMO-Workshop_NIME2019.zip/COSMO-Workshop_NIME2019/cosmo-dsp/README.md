# cosmo-dsp

The COSMO DSP library contains ready-made csound audio effects (DSP-Library/Effects).

Find a detailed manual and introduction [here](http://cosmoproject.github.io/dsp/).
